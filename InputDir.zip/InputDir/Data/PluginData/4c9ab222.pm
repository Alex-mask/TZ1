#line 1 "C:/Perl/lib/Tie/Hash/NamedCapture.pm"
use strict;
package Tie::Hash::NamedCapture;

our $VERSION = "0.09";

require XSLoader;
XSLoader::load(); # This returns true, which makes require happy.

__END__

#line 50
