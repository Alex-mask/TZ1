#line 1 "C:/Perl/lib/PerlIO/scalar.pm"
package PerlIO::scalar;
our $VERSION = '0.24';
require XSLoader;
XSLoader::load();
1;
__END__

#line 42
